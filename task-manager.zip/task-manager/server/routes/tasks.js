import { Router } from "express";
import Task from "../models/Task.js";
import auth from "../middleware/auth.js";

const router = Router();
router.use(auth); // every task route needs a valid token

// Get all tasks of the logged-in user
router.get("/", async (req, res, next) => {
  try {
    const tasks = await Task.find({ user: req.userId }).sort({ completed: 1, dueDate: 1, createdAt: -1 });
    res.json(tasks);
  } catch (e) { next(e); }
});

router.post("/", async (req, res, next) => {
  try {
    const { title, priority, dueDate } = req.body;
    if (!title?.trim()) return res.status(400).json({ message: "Task title is required" });
    const task = await Task.create({ user: req.userId, title, priority, dueDate: dueDate || undefined });
    res.status(201).json(task);
  } catch (e) { next(e); }
});

router.put("/:id", async (req, res, next) => {
  try {
    const { title, priority, dueDate, completed } = req.body;
    const task = await Task.findOneAndUpdate(
      { _id: req.params.id, user: req.userId }, // users can only edit their own tasks
      { title, priority, dueDate: dueDate || null, completed },
      { new: true, runValidators: true, omitUndefined: true }
    );
    if (!task) return res.status(404).json({ message: "Task not found" });
    res.json(task);
  } catch (e) { next(e); }
});

router.delete("/:id", async (req, res, next) => {
  try {
    const task = await Task.findOneAndDelete({ _id: req.params.id, user: req.userId });
    if (!task) return res.status(404).json({ message: "Task not found" });
    res.json({ message: "Task deleted" });
  } catch (e) { next(e); }
});

export default router;
